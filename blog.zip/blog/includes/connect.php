<?php
$con = mysqli_connect("localhost","root","","blog") or die("Error with Connection");
$db = new mysqli("localhost","root","","blog") or die("Error with Connection");
?>